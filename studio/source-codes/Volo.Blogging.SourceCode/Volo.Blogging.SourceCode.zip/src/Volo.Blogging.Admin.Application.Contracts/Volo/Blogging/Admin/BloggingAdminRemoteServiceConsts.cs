﻿namespace Volo.Blogging.Admin
{
    public static class BloggingAdminRemoteServiceConsts
    {
        public const string RemoteServiceName = "BloggingAdmin";

        public const string ModuleName = "bloggingAdmin";
    }
}
