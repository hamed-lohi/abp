﻿using Volo.Abp.Modularity;

namespace Volo.Abp.BackgroundJobs
{
    public class AbpBackgroundJobsDomainSharedModule : AbpModule
    {
        
    }
}
